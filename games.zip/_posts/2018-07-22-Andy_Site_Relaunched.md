---

layout: post title: "Andy Launches Site"

date: 2018-07-22
---

Finally got around to relaunching this site with [Jekyll](http://jekyllrb.com) and I can use Markdown to author my posts.
